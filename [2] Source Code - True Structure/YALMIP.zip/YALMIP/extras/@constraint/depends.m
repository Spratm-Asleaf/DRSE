function vars = depends(F)

vars = depends(lmi(F));