function P = polytope(C)
%POLYTOPE (Overloaded)

P = polytope(lmi(C));