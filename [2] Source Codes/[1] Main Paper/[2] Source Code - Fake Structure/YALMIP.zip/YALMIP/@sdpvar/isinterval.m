function res = isinterval(Y)
%ISINTERVAL (overloaded)

res = isa(Y.basis,'intval');
